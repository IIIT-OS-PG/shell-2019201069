#ifndef COMMAND
#define COMMAND
#include<string>
#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<fcntl.h>
#include<errno.h>
#include<stdlib.h>
#include<signal.h>
#include<unordered_map> 
#define MAXIM 300

using namespace std;

unordered_map <char*, char*> umap;

void checkifalias(char* str){
	int i = 0, j =0;
	char* checkalias = strtok(str," ");
	printf("\n \n %s", str);
	printf("here in alias\n");
	printf("%s", checkalias);
	printf("%s", umap[checkalias]);
	printf("here in alias 2");
	char* temp;
	char* tempstr = str;
		if(umap.find(checkalias) != umap.end()){
			printf("%s",umap[checkalias]);
			
			temp = umap[checkalias];
			tempstr = umap[checkalias];
			while (temp != NULL){
				temp++;
				j++;
			}
			
			while (checkalias != NULL){
				checkalias++;
				i++;
			}
			
			str = str+i;
			i = 1 ;
			while(str != NULL){
				*(tempstr + i + j) = *(str + i);
				i++;
				str++;				
			}
			
			str = tempstr;
		}
	//string.replace(0, strlen(checkalias), umap[first]);
}

int checkcommand(char string[MAXIM], char *com[MAXIM]){

	int i = 0;
	com[0] = strtok(string," ");	
	while(com[i] != NULL){ 
		com[++i] = strtok(NULL, " ");	
	}

return i;

}

int executepipe(char *pipetoken[MAXIM])
{   
	int pfd[2], fdp = 0, ptid, i = 0;
	
	while(pipetoken[i] != NULL)
	{
		
		pipe(pfd);
		ptid = fork();
		if(ptid < 0)
		{
			printf("error in forking\n");
			return -1;
		}
		else if(ptid == 0)
  		{
    		dup2(fdp, STDIN_FILENO);
    		
   			if(pipetoken[i+1] !=  NULL)
    			dup2(pfd[1], STDOUT_FILENO);
    			
    		close(pfd[0]);
    		close(pfd[1]);
    		char *com[MAXIM];
    		checkcommand(pipetoken[i] , com);
    		int err = execvp(com[0], com);
    		if(err < 0){
					printf("unknown command\n");
				}
   		}
  		 else  // parent process
  		 {
  		 	wait(0);
   			close(pfd[1]);
   			fdp = pfd[0];
   			i++;
  		 }	
  		 
  	}

	return 0;
}


int checkforpipe(char string[MAXIM], char *pipetokens[MAXIM])
{
	int pipes = 0;
	pipetokens[0]=strtok(string,"|");
	
	while(pipetokens[pipes] != NULL)
	{
		pipetokens[++pipes] = strtok(NULL,"|");
		//printf("%d", pipes);
	}
	
	return pipes-1;
}

int readcommand(char string[MAXIM]){
	char c;
	int j = 0; 
	while ((c = getchar()) != '\n' && (c != EOF) ) {
       				 string[j] = c;
  	if (c == '\t'){   
     				printf("\n tab daabla re baba \n")  ; 
     				   
     				 }
					j++;
    			}
    string[j] = '\0';
    return j;
}



int checkredir(char *com[MAXIM], int i, char *filename){

				int redir = 0;	
				
					char *red = com[i-2];
					
					if(strcmp(red, ">>") == 0){
							filename = com[i-1];
							redir = 3;
							com[i-2] = NULL;    // overwrite >
							com[i-1] = NULL;	
					}
					else if(strcmp(red, "<") == 0){
							printf("in");
							filename = com[i-1];
							redir = 2;
							com[i-2] = NULL;    // overwrite <	
							com[i-1] = NULL; 
					}
					else if(strcmp(red, ">") == 0){
							filename = com[i-1];
							redir = 1;
							com[i-2] = NULL;    // overwrite >
							com[i-1] = NULL;	
					}
				
				//fflush(stdout);

return redir;

}


#endif