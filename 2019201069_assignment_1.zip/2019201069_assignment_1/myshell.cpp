#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<string>
#include<fcntl.h>
#include<errno.h>
#include<stdlib.h>
#include<signal.h>
#include<unordered_map> 
#include<termios.h>
#define MAXIM 300
#include "parseEnv.h"
#include "commands.h"
#include<termios.h>

using namespace std;


int chid, id, pid;
void prompt();

void ctrlchandler(int signo)
{
	if(chid == pid) return;
	else{
	printf("killed\n");
	//kill(,SIGINT);
	prompt();
	}
}

static struct termios oldio, newio;
   

void prompt(){

	while(1){
			
				int i = 0, redir = 0, fd, back = 0, status, pipes = 0, k = 0;
				char currdir[MAXIM];
				char *aliaslhs, *aliasrhs;
				char *pipetokens[20];
				char *cwd = getcwd(currdir, sizeof(currdir));
				printf("\n user is %d ", getuid());
				if(getuid() == 0){
					printf("rootuserhere# ");
				}
				else if(strcmp(cwd, gethome()) == 0){
					printf("%s~ ",gethost());
				}
				else{
					printf("%s->%s$ ",gethost(),cwd);	
				}
							
				char *com[MAXIM];
				char string[MAXIM];
				char *filename, *pathname;
				readcommand(string);
				
				char *fullcommand = string;
				
				if(strncmp(fullcommand, "alias", 5) == 0){
					//printf("\n alias me aa gaya hu re bhaiya ji %s\n", fullcommand);
					strtok(fullcommand, " ");
					aliaslhs = strtok(NULL, "=");
					aliasrhs = strtok(NULL,"\"");
					//printf("rhs %s", aliasrhs);
					//printf("lhs %s\n", aliaslhs);
					umap[aliaslhs] = aliasrhs;
					continue;
				}
				
				//checkifalias(fullcommand);
				
				i = checkcommand(string, com);
				char *first = com[0];
				
				if(strncmp(first, "cd", 2) == 0){
					pathname = com[1];
					//printf("\n\n le behen %s", pathname);
					chdir(pathname);
					continue;
				}
				
				pipes = checkforpipe(string, pipetokens);
				printf("%d",pipes);
				if(pipes > 0){
					executepipe(pipetokens);
					continue;
				}
				
				
				
				
				
				
				// checking for background
				char *background = com[i - 1];
				if(strcmp(background, "&") == 0)
				{
					com[i-1] = NULL;
					back = 1;
					//close(STDOUT_FILENO);
					//close(STDIN_FILENO);
				}
				
				
				// i o redirection
				if(i > 2)
					redir = checkredir(com, i, filename);
						
				id =  fork();	
				if(id < 0)
				{
					printf("error in forking\n");
				}	
				signal(SIGINT, ctrlchandler);
				if(id == 0)
				{
				if(redir == 1){
					close(STDOUT_FILENO);  // to close stdout
					fd = open(filename, O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR);
				}
				if(redir == 2){
					close(STDIN_FILENO);   // to close stdin
					fd = open(filename, O_RDONLY);
				}
				if(redir == 3){
					printf("here in redir >>");
					close(STDOUT_FILENO);  // to close stdout
					fd = open(filename, O_WRONLY | O_APPEND , S_IRUSR | S_IWUSR);
					if(fd<0){
						fd = open(filename, O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR);   // open new if not present
					}
				}
			
				int err = execvp(com[0],com);
				if(err < 0){
					printf("unknown command\n");
				}
			}
			else if (id > 0){  // parent process returns chid
				chid = id;
				//printf("child process : %d\n", chid);
				if (back == 0)
					wait(0);
				else
				{
					printf("[the process %d started]\n", chid);
					//close(STDOUT_FILENO);
					//waitpid(pid, &status, WNOHANG);
					prompt();					
				}
			}
		else{
			printf("error in forking\n");
		}

}
}


int main()
{
	
	tcgetattr(0, &oldio);
    newio = oldio;
    newio.c_lflag &= ~ICANON;
    //newio.c_lflag &= ~ECHO;
    tcsetattr(0, TCSANOW, &newio);
	char pathvar[2048];
	pid = getpid();
	uid_t uid;
	getinfo(); // export info from /etc
	getpath(pathvar);
	uid = getuid();
	//printf("%d\n", uid);
	char uids[MAX];
	tostr(uids, uid);
	getuserinfo(uids);	// get info about a user
	
	printf("path : \n %s \n\n", pathvar);
// 	printf("%s\n", gethost());
// 	printf("%s\n", gethome());
// 	//printf("%s\n", getpath(p));
// 	printf("%s\n", getps1());
	
	prompt();

			
}




