#ifndef  PARSE
#define PARSE

#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<fcntl.h>
#include<errno.h>
#include<stdlib.h>
#include<signal.h>
#include <math.h> 
#define MAX 2048

using namespace std;

char path[MAX] = "/etc/paths";
char passwd[MAX] = "/etc/passwd";
char *userinfo[MAX];

// root:*:0:0:System Administrator:/var/root:/bin/sh
// # PATH : /etc/paths
// # HOME : /etc/passwd
// # USER : /etc/passwd
// # HOSTNAME : /etc/passwd
// # PS1 : \h:\W \u\$


// convert uid int to string
void tostr(char str[MAX], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

char *getpath(char content[MAX]){
	int  i = 0;
	long bytes;
	char ch;
	char *data[MAX];
	//FILE * fpi = fopen(path, "r");
	//FILE * fpo = fopen("path.txt","w+");
	
	int fd = open(path, O_RDONLY);
	int fp = open("path.txt", O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR);
	
	if(fd<0){
		printf("File could not be opened \n");
		perror("open");
		return 1;
	}

	else{
		bytes = read(fd, content, sizeof(content)-1);
	}
	
	fprintf(fp,"%s",content);
}


char * getps1(){
	return "\\h:\\W \\u\\$";
}

char * gethome(){
	return userinfo[3];
}

char * gethost(){
	return userinfo[2];
}

char * getuser(){
	return userinfo[1];
}

int getuserinfo(char * uid){

	
	int  i = 0;
	char content[MAX*MAX];
	long bytes;
	char *data[MAX];

	int fd = open("bashrc.txt", O_RDONLY);
	if(fd<0){
		printf("File could not be opened \n");
		perror("open");
		return 1;
	}

	else{
		bytes = read(fd, content, sizeof(content)-1);
	}
	
	int j = 0;
	data[0] = strtok(content, ":");
	while(data[i] != NULL){
	//printf("here 1");
		i = 0;
		if(j)
			data[i] = strtok(NULL, ":");
		while(i < 2){	
			data[++i] = strtok(NULL, ":");
		}
		data[++i] = strtok(NULL, "\n");
		if(strcmp(data[0],uid) == 0){
		//printf("here 2");
			for(int k = 0; k < 4; k++){
				 userinfo[k] = data[k];
				 //printf("%s\n", data[k]);
			} 
			break;
		}
		j++;
	}
	close(fd);
	return 0;

}


int getinfo(){

	int  i = 0;
	char content[MAX*MAX];
	long bytes;
	char *data[MAX];
	char *temp[MAX];
	FILE *fdbash;
	
	
	 if((fdbash = fopen("bashrc.txt", "r")))
    {
        fclose(fdbash);
        printf("File already exists, initializations already done\n");
        return -1;
    }
    
    fdbash = fopen("bashrc.txt", "w+");
	
	int fd = open(passwd, O_RDONLY);
	if(fd<0){
		printf("File could not be opened \n");
		perror("open");
		return 1;
	}

	else{
		bytes = read(fd, content, sizeof(content)-1);
	}
	
	
	strtok(content, "##");
	strtok(NULL, "##");

	int j = 0;
	data[0] = strtok(NULL, ":");
	while(data[i] != NULL){
		i = 0;
		if(j)
			data[i] = strtok(NULL, ":");
		//while(strncmp(data[i], " ", 1) != 0){	
		while(i < 5){	
			data[++i] = strtok(NULL, ":");
		}
		data[++i] = strtok(NULL, "\n");
		printf("USER 0: %s \n",data[0]);
		printf("UID 2: %s",data[2]);
		printf("HOSTNAME 4: %s \n",data[4]);
		printf("HOME 5: %s \n",data[5]);
		
		fprintf(fdbash, "%s:%s:%s:%s\n",data[2],data[0],data[4],data[5]);
		
		j++;
	}
	close(fd);
	fclose(fdbash);
	return 0;

}

#endif